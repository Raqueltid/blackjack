import { Component } from '@angular/core';
import { DeckService} from '../../services/deck.service';

@Component({
  selector: 'game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.scss']
})
export class GameComponent {
    
    public endMsg: String;
    public isFinished: Boolean = false;
    private dealer = {      
        'scores': [0],
        'cards': [],
        'a': 0
    };

    private player = {      
        'scores': [0],
        'cards': [],
        'a': 0
    };
    
    constructor(private deckService: DeckService) {  
        this.initializeGame();      
    }

    public hit(){
        this.player.cards.push(this.deckService.getCard());
        this.player.scores = this.calculateScore(this.player.cards);
        this.checkScore(this.player.scores, false);
    }

    public stick(){
        this.dealer.cards.push(this.deckService.getCard());
    }
    
    private initializeGame () {
        //Reset status
        this.isFinished = false;

        //Reset deck
        this.deckService.initializeDeck();
        
        //Get four cards from deck
        let cards = [];
        for( let i=0; i<4; i++ ) {
            cards.push(this.deckService.getCard());
        }

        //Reset cores
        this.dealer.scores = [0];
        this.player.scores = [0];
        
        //Set the cards and scores
        this.dealer.cards = [cards[0], cards[1]];        
        this.player.cards = [cards[2], cards[3]];    
        this.dealer.scores = this.calculateScore(this.dealer.cards);
        this.player.scores = this.calculateScore(this.player.cards);
        
        this.checkScore(this.dealer.scores, true);
        if( !this.isFinished ) {
            this.checkScore(this.player.scores, false);
        }
    }

    private checkScore(scores: Array<Number>, isDealer: Boolean) {   
        //Blackjack
        const win = scores.filter(score => score == 21);    
        if ( win.length > 0 ) {
            this.endMsg =  (isDealer) ? 'Sorry, Dealer has Blackjack.':'Congratulations, You have Blackjack!!';
            this.endGame();            
        } else {
            // Major than 21
            const lost = scores.filter(score => score > 21);
            if( lost.length === scores.length  ){
                console.log(lost);
                this.endMsg =  (isDealer) ? 'Congratulations, You win!!':'Sorry, Dealer win.';
                this.endGame();
            }     
        }
    }

    private endGame() {
        this.isFinished = true; 
    }

    private calculateScore(cards) {
        let scores = [];
        let score = 0;
        let a = 0;
        cards.forEach(card => {
            score = score + card.value;
            //Check for As
            if (card.value == 1) {
                a++;    
            }
        });

        scores.push(score);
        //If there is one or more as 
        if( a > 0 ) {
            for(let i = 0; i<a; i++) {
                const alternativeValue = 10 * ( i + 1);
                scores.push(score + alternativeValue);              
            }
        }
        return scores;
    }   
}