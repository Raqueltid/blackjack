import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit{
    @Input('card') card: any;
    @Input('isDealer') isDealer: boolean;

    constructor() {
      
    }
    ngOnInit(){
      console.log(this.card);
      console.log(this.isDealer);
    } 
}