export interface Deck {
    id: string;
    value: string;   
}    